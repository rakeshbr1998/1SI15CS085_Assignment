


from django.contrib import admin
from .models import Aadhar_card,Voter_id,contestent,constituency,E_officer

admin.site.register(Aadhar_card)
admin.site.register(Voter_id)
admin.site.register(contestent)
admin.site.register(constituency)
admin.site.register(E_officer)
# Register your models here.
