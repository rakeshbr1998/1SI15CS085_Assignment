#include <stdio.h>
 #include <stdlib.h>
typedef struct data{ int wt, ta, bt, at, ind;
};
int n ;
struct data timeArr[10], val; void insertionSort()
{
int i, k;
for(i=0; i < n; i++){ val = timeArr[i]; k = i-1;
while(k>=0 && timeArr[k].at > val.at){ timeArr[k+1] = timeArr[k];
k--;
}
timeArr[k+1]=val;
}
}

int main()
{
int i,k, time=0;
float avwt=0.0,avta=0.0; printf("\nEnter number of processes: "); scanf("%d",&n);
printf("\nEnter Arrival times and burst times of processes:\n"); for(i=0; i < n; i++)
{
scanf("%d%d", &timeArr[i].at, &timeArr[i].bt); timeArr[i].ind=i;
}

insertionSort();

for(i = 0; i < n; i++){
int tem=time-timeArr[i].at; if(tem<0)
{
printf("|%d| --- ", time); time = timeArr[i].at;
}
timeArr[i].wt = time - timeArr[i].at;
 
timeArr[i].ta = time + timeArr[i].bt - timeArr[i].at; printf( "|%d| P%d ", time, timeArr[i].ind);
time += timeArr[i].bt; avwt += timeArr[i].wt; avta += timeArr[i].ta;
}
printf("|%d|\n", time); printf("\n\nPR\tAT\tBT\tWT\tTA\n"); for(i=0;i<n;i++)
printf("P%d\t%d\t%d\t%d\t%d\n",timeArr[i].ind, timeArr[i].at, timeArr[i].bt, timeArr[i].wt, timeArr[i].ta);
printf("\n\nAvg. waiting time: %f \nAvg. turn around time: %f", avwt/n, avta/n);
}
