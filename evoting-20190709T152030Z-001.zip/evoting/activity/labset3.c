#include<stdlib.h>
#include<stdio.h>
int main()
{
int allocation[10][5],need[10][5],MAX[10][5],available[10];
int i,j,n,r,arr[10],flag[10],remain,k=0,dead;
printf("Enter number of processes and resources\n");
scanf("%d%d",&n,&r);
remain=n;
dead=n*n;
printf("Enter the allocation matrix\n");
for(i=0;i<n;i++)
{
flag[i]=0;
for(j=0;j<r;j++)
scanf("%d",&allocation[i][j]);
}
printf("Enter MAX Matrix\n");
for(i=0;i<n;i++)
for(j=0;j<r;j++)
{
scanf("%d",&MAX[i][j]);
need[i][j]=MAX[i][j]-allocation[i][j];
}
printf("Enter available resources:\n");
for(j=0;j<r;j++)
scanf("%d",&available[j]);
for(i=0;remain!=0;)
{
j=0;
if(flag[i]==0)
{
while(flag[i]==0&&need[i][j]<=available[j])
{
j++;
if(j==r)
flag[i]=1;
} if(flag[i]==1)
{
for(j=0;j<r;j++)
available[j]+=allocation[i][j];
arr[k++]=i;
remain--;
}
} i=(i+1)%n;
if((dead--)==0)
break;
} if(remain==0)
{
printf("\n\nSafe sequence exists\nthe safe sequence is\n");
for(i=0;i<n;i++)
printf("P%d\n",arr[i]);
printf("\n");
}
else
printf("\n\n System is in deadlock state :\n");
return 0;
}

//op
